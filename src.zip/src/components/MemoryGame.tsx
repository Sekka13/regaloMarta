/**
 * ============================================================================
 *  MemoryGame.tsx — Memorama de 6 parejas
 * ============================================================================
 *
 *  REGLAS
 *  ------
 *  1. Hay 12 cartas (6 iconos x 2) boca abajo y barajadas.
 *  2. El jugador da la vuelta a 2 cartas por turno.
 *  3. ACIERTO  -> la pareja se queda boca arriba, suena `level_up` y se avisa al
 *                 padre con `onLevelComplete` (cada pareja = 1 "nivel").
 *                 Si era la ÚLTIMA pareja, suena `victory_game` en vez de `level_up`.
 *  4. FALLO    -> suena `fail_level` y se vuelven a dar la vuelta las cartas que
 *                 estaban boca arriba sin emparejar. Las parejas ya acertadas
 *                 se quedan boca arriba.
 *  5. Al acertar las 6 parejas aparece la pantalla de victoria con el botón
 *     "Jugar de nuevo" (baraja de nuevo y reinicia).
 *
 *  USO DESDE EL PADRE
 *  ------------------
 *    <MemoryGame
 *      onLevelComplete={() => ...}   // opcional: se llama tras CADA pareja acertada
 *      onGameComplete={() => ...}    // opcional: se llama al acertar la última pareja
 *    />
 *
 *  GUÍA RÁPIDA: "QUIERO CAMBIAR X, ¿QUÉ TOCO?"
 *  --------------------------------------------
 *  - Qué iconos / cuántas parejas ............ MEMORY_ICONS (PAIRS_TOTAL se calcula solo)
 *  - Tiempo que se ve un fallo ................ MISMATCH_DELAY_MS
 *  - Pausa tras acertar ....................... MATCH_UNLOCK_DELAY_MS
 *  - Pausa antes de la pantalla de victoria ... WIN_OVERLAY_DELAY_MS
 *  - Diseño de la carta (reverso / frente) .... bloque JSX "Reverso" y "Frente"
 *  - Duración del giro ........................ FLIP_DURATION_S
 *  - Columnas del tablero ..................... `grid-cols-3` en el JSX del tablero
 *  - Texto / color de la victoria ............. bloque JSX "Pantalla de victoria"
 * ============================================================================
 */

import { useCallback, useEffect, useRef, useState } from 'react';
import { motion, useReducedMotion } from 'framer-motion';
import { Play, Sparkles } from 'lucide-react';
import ballIcon from '../../public/icons/ball.png';
import dollIcon from '../../public/icons/doll.png';
import legoMIcon from '../../public/icons/lego_m.png';
import legoWIcon from '../../public/icons/lego_w.png';
import teddyIcon from '../../public/icons/teddy.png';
import yoyoIcon from '../../public/icons/yoyo.png';
import { playSoundAndVibrate } from '../utils/soundHelper';

/** Tipo del nombre de sonido que acepta tu helper (evita errores de TS con 'victory_game'). */
type SoundName = Parameters<typeof playSoundAndVibrate>[0];

// ============================================================================
//  TIPOS
// ============================================================================

type MemoryIcon = {
  id: string;
  label: string;
  src: string;
};

/** Una carta concreta del tablero (cada icono genera 2 cartas con el mismo `pairId`). */
type MemoryCard = {
  uid: string;
  pairId: string;
  label: string;
  src: string;
};

type MemoryGameProps = {
  /** Se llama cada vez que se acierta una pareja (equivale a "nivel completado"). */
  onLevelComplete?: () => void;
  /** Se llama una vez, al acertar la última pareja. */
  onGameComplete?: () => void;
};

// ============================================================================
//  CONSTANTES DE AJUSTE
// ============================================================================

/** Iconos del juego: cada uno forma una pareja. Cambia aquí los iconos o las etiquetas. */
const MEMORY_ICONS: MemoryIcon[] = [
  { id: 'yoyo', label: 'Yoyó', src: yoyoIcon },
  { id: 'lego_m', label: 'Lego M', src: legoMIcon },
  { id: 'lego_w', label: 'Lego W', src: legoWIcon },
  { id: 'ball', label: 'Pelota', src: ballIcon },
  { id: 'doll', label: 'Muñeca', src: dollIcon },
  { id: 'teddy', label: 'Osito', src: teddyIcon },
];

/** Número de parejas (= número de "niveles"). */
const PAIRS_TOTAL = MEMORY_ICONS.length;

/** Tiempo (ms) que se ven las dos cartas fallidas antes de volver a taparse. */
const MISMATCH_DELAY_MS = 900;

/** Tiempo (ms) de bloqueo tras acertar una pareja (para que acabe la animación). */
const MATCH_UNLOCK_DELAY_MS = 450;

/** Tiempo (ms) entre acertar la última pareja y mostrar la pantalla de victoria. */
const WIN_OVERLAY_DELAY_MS = 900;

/** Duración (s) del giro de una carta. */
const FLIP_DURATION_S = 0.4;

// ============================================================================
//  FUNCIONES AUXILIARES
// ============================================================================

/** Crea las 12 cartas (2 por icono) y las baraja con Fisher–Yates. */
function buildDeck(): MemoryCard[] {
  const cards: MemoryCard[] = MEMORY_ICONS.flatMap((icon) =>
    [0, 1].map((copy) => ({
      uid: `${icon.id}-${copy}`,
      pairId: icon.id,
      label: icon.label,
      src: icon.src,
    })),
  );

  for (let i = cards.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [cards[i], cards[j]] = [cards[j], cards[i]];
  }
  return cards;
}

// ============================================================================
//  COMPONENTE PRINCIPAL
// ============================================================================

export function MemoryGame({ onLevelComplete, onGameComplete }: MemoryGameProps) {
  const reduceMotion = Boolean(useReducedMotion());

  // --------------------------------------------------------------------------
  //  REFS (fuente de verdad para la lógica; evitan leer estado desactualizado)
  // --------------------------------------------------------------------------
  const busyRef = useRef(false); // true = no se aceptan toques (animación / comparación en curso)
  const flippedRef = useRef<number[]>([]); // índices de cartas boca arriba SIN emparejar
  const matchedRef = useRef<string[]>([]); // pairIds ya acertados
  const timeoutsRef = useRef<number[]>([]); // timeouts pendientes (para limpiarlos)
  const onLevelCompleteRef = useRef(onLevelComplete);
  const onGameCompleteRef = useRef(onGameComplete);

  onLevelCompleteRef.current = onLevelComplete;
  onGameCompleteRef.current = onGameComplete;

  // --------------------------------------------------------------------------
  //  ESTADO (lo que dibuja la interfaz)
  // --------------------------------------------------------------------------
  const [deck, setDeck] = useState<MemoryCard[]>(() => buildDeck());
  const [flipped, setFlipped] = useState<number[]>([]);
  const [matchedIds, setMatchedIds] = useState<string[]>([]);
  const [fails, setFails] = useState(0);
  const [showWin, setShowWin] = useState(false);
  const [statusMessage, setStatusMessage] = useState('Encuentra las 6 parejas.');

  // --------------------------------------------------------------------------
  //  TIMEOUTS: helper para programar y limpiar
  // --------------------------------------------------------------------------
  const schedule = useCallback((fn: () => void, ms: number) => {
    const id = window.setTimeout(() => {
      timeoutsRef.current = timeoutsRef.current.filter((t) => t !== id);
      fn();
    }, ms);
    timeoutsRef.current.push(id);
  }, []);

  const clearTimers = useCallback(() => {
    timeoutsRef.current.forEach((t) => window.clearTimeout(t));
    timeoutsRef.current = [];
  }, []);

  // Limpieza al desmontar
  useEffect(() => () => clearTimers(), [clearTimers]);

  // --------------------------------------------------------------------------
  //  LÓGICA: tocar una carta
  // --------------------------------------------------------------------------
  const handleCardClick = (index: number) => {
    if (busyRef.current) return; // hay una comparación o animación en curso

    const card = deck[index];
    if (matchedRef.current.includes(card.pairId)) return; // ya acertada
    if (flippedRef.current.includes(index)) return; // ya está boca arriba

    // Dar la vuelta a la carta
    const nextFlipped = [...flippedRef.current, index];
    flippedRef.current = nextFlipped;
    setFlipped(nextFlipped);

    if (nextFlipped.length < 2) return; // falta la segunda carta del turno

    // Hay 2 cartas boca arriba: bloquear toques y comparar
    busyRef.current = true;
    const [first, second] = nextFlipped;
    const isMatch = deck[first].pairId === deck[second].pairId;

    if (isMatch) {
      // ---------------- ACIERTO ----------------
      const pairId = deck[first].pairId;
      const nextMatched = [...matchedRef.current, pairId];
      matchedRef.current = nextMatched;
      setMatchedIds(nextMatched);

      flippedRef.current = [];
      setFlipped([]);

      const isLastPair = nextMatched.length === PAIRS_TOTAL;

      // Última pareja -> victory_game ; resto -> level_up
      playSoundAndVibrate((isLastPair ? 'victory_game' : 'level_up') as SoundName);
      onLevelCompleteRef.current?.();

      if (isLastPair) {
        setStatusMessage('¡Has encontrado todas las parejas!');
        // busyRef se queda en true: el tablero queda bloqueado hasta "Jugar de nuevo"
        schedule(() => {
          setShowWin(true);
          onGameCompleteRef.current?.();
        }, WIN_OVERLAY_DELAY_MS);
      } else {
        setStatusMessage(`¡Pareja encontrada! ${nextMatched.length}/${PAIRS_TOTAL}`);
        schedule(() => {
          busyRef.current = false;
        }, MATCH_UNLOCK_DELAY_MS);
      }
    } else {
      // ---------------- FALLO ----------------
      playSoundAndVibrate('fail_level');
      setFails((current) => current + 1);
      setStatusMessage('¡Fallaste! Inténtalo de nuevo.');

      // Dejamos ver las cartas un momento y después se tapan de nuevo
      schedule(() => {
        flippedRef.current = [];
        setFlipped([]);
        busyRef.current = false;
      }, MISMATCH_DELAY_MS);
    }
  };

  // --------------------------------------------------------------------------
  //  REINICIAR (botón "Jugar de nuevo")
  // --------------------------------------------------------------------------
  const handleRestart = () => {
    clearTimers();
    busyRef.current = false;
    flippedRef.current = [];
    matchedRef.current = [];
    setFlipped([]);
    setMatchedIds([]);
    setFails(0);
    setShowWin(false);
    setDeck(buildDeck());
    setStatusMessage('Encuentra las 6 parejas.');
  };

  // --------------------------------------------------------------------------
  //  RENDER
  // --------------------------------------------------------------------------
  return (
    <section className="memory-game-panel grid gap-2 w-full" aria-label="Juego de memorama">
      {/* ---------- Barra superior: parejas y fallos ---------- */}
      <div className="memory-game-toolbar flex items-center justify-between px-2">
        <div className="flex items-center gap-3">
          <span className="memory-pairs font-semibold text-purple-700 bg-purple-50 px-3 py-1 rounded-full border border-purple-200 text-sm">
            {matchedIds.length}/{PAIRS_TOTAL} parejas
          </span>
          <span className="memory-fails font-semibold text-pink-600 bg-pink-50 px-3 py-1 rounded-full border border-pink-200 text-sm">
            Fallos: {fails}
          </span>
        </div>
      </div>

      {/* ---------- Tablero ---------- */}
      <div className="memory-board relative w-full max-w-sm mx-auto rounded-2xl border-2 border-pink-300 bg-gradient-to-b from-pink-50/70 via-purple-50/50 to-pink-100/70 p-3 shadow-inner select-none overflow-hidden">
        {/* Cambia `grid-cols-3` para otro número de columnas */}
        <div className="grid grid-cols-3 gap-3">
          {deck.map((card, index) => {
            const isMatched = matchedIds.includes(card.pairId);
            const faceUp = isMatched || flipped.includes(index);

            return (
              <button
                key={card.uid}
                type="button"
                onClick={() => handleCardClick(index)}
                disabled={faceUp}
                className="memory-card relative aspect-square w-full cursor-pointer disabled:cursor-default focus:outline-none focus-visible:ring-4 focus-visible:ring-pink-400 rounded-xl"
                style={{ perspective: 800 }}
                aria-label={faceUp ? `${card.label}, boca arriba` : 'Carta boca abajo'}
              >
                {/* Contenedor que gira (rotateY) y hace un pequeño "pulso" al acertar */}
                <motion.div
                  className="absolute inset-0"
                  style={{ transformStyle: 'preserve-3d' }}
                  initial={false}
                  animate={{
                    rotateY: faceUp ? 180 : 0,
                    scale: isMatched ? [1, 1.08, 1] : 1,
                  }}
                  transition={{ duration: reduceMotion ? 0 : FLIP_DURATION_S, ease: 'easeInOut' }}
                >
                  {/* ---- Reverso (boca abajo) ---- */}
                  <div
                    className="absolute inset-0 flex items-center justify-center rounded-xl border-2 border-black bg-gradient-to-br from-pink-400 to-purple-500 shadow-[0_3px_0_0_rgba(0,0,0,0.8)]"
                    style={{ backfaceVisibility: 'hidden', WebkitBackfaceVisibility: 'hidden' }}
                  >
                    <Sparkles size={28} className="text-white/90" aria-hidden="true" />
                  </div>

                  {/* ---- Frente (boca arriba) ---- */}
                  <div
                    className={`absolute inset-0 flex items-center justify-center rounded-xl border-2 shadow-[0_3px_0_0_rgba(0,0,0,0.8)] ${
                      isMatched ? 'bg-emerald-50 border-emerald-500' : 'bg-white border-black'
                    }`}
                    style={{
                      backfaceVisibility: 'hidden',
                      WebkitBackfaceVisibility: 'hidden',
                      transform: 'rotateY(180deg)',
                    }}
                  >
                    <img
                      src={card.src}
                      alt=""
                      draggable={false}
                      className="w-3/5 h-3/5 object-contain drop-shadow-sm"
                    />
                  </div>
                </motion.div>
              </button>
            );
          })}
        </div>

        {/* ---------- Pantalla de victoria ---------- */}
        {showWin && (
          <div className="absolute inset-0 z-40 flex flex-col items-center justify-center bg-black/50 backdrop-blur-sm p-4 text-center">
            <div className="text-5xl font-black tracking-wider mb-6 transform animate-bounce [-webkit-text-stroke:3px_currentColor] text-emerald-500">
              ¡VICTORIA!
            </div>

            <button
              type="button"
              onClick={handleRestart}
              className="flex items-center gap-2 px-8 py-4 bg-pink-500 hover:bg-pink-600 active:scale-95 text-white font-bold text-lg rounded-2xl shadow-[0_6px_0_0_rgba(157,23,77,1)] border-2 border-white transition-all cursor-pointer"
            >
              <Play size={22} fill="currentColor" />
              Jugar de nuevo
            </button>
          </div>
        )}
      </div>

      {/* ---------- Mensaje de estado (accesible) ---------- */}
      <p
        className="memory-game-status text-xs text-center font-medium text-purple-600 h-5"
        role="status"
        aria-live="polite"
      >
        {statusMessage}
      </p>
    </section>
  );
}